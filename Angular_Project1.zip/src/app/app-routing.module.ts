import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomepageComponent } from './app-features/homepage/homepage.component';

const routes: Routes = [
  {
    path: '', // Homepage, path has empty parameter
    component: HomepageComponent
  },
  {
    path: 'appFeatures',  // using lazy loading
    loadChildren: ()=> import('./app-features/app-features.module').then(m => m.AppFeaturesModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
