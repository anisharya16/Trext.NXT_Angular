import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppFeaturesRoutingModule } from './app-features-routing.module';
import { EventsComponent } from './events/events.component';
import { ResourcesComponent } from './resources/resources.component';
import { FeaturesComponent } from './features/features.component';
import { HomepageComponent } from './homepage/homepage.component';


@NgModule({
  declarations: [EventsComponent, ResourcesComponent, FeaturesComponent, HomepageComponent],
  imports: [
    CommonModule,
    AppFeaturesRoutingModule
  ]
})
export class AppFeaturesModule { }
