import { NewDirectiveDirective } from './new-directive.directive';

describe('NewDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new NewDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
